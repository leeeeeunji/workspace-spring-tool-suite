package com.itwill.ej_final_project.controller;

public class TripBoardController {

}
