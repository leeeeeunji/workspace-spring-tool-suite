package com.itwill.ej_final_project.service;

public class TripBoardService {

}
