package com.itwill;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjFinalProjectTeam2MyRealKoreaApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjFinalProjectTeam2MyRealKoreaApplication.class, args);
	}

}
