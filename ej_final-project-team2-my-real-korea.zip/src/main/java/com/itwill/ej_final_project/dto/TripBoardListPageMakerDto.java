package com.itwill.ej_final_project.dto;

import java.util.List;

import com.itwill.ej_final_project.util.PageMaker;

public class TripBoardListPageMakerDto {
	public List<TripBoard> writingList;
	public PageMaker pageMaker;
}
