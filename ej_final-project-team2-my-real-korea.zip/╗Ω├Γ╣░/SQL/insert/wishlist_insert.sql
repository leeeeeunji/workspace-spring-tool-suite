insert into wishlist(wish_no,user_id) values(WISHLIST_WISH_NO_SEQ.nextval,'admin');
insert into wishlist(wish_no,user_id) values(WISHLIST_WISH_NO_SEQ.nextval,'user1');
insert into wishlist(wish_no,user_id) values(WISHLIST_WISH_NO_SEQ.nextval,'user2');
